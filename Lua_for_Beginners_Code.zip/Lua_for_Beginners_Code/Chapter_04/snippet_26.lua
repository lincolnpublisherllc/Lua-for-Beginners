-- list-like
local colors = {"red", "green", "blue"}
print(colors[1])           -- red
print(#colors)             -- 3

-- map-like
local ages = {alice = 30, bob = 27}
print(ages.alice)          -- 30