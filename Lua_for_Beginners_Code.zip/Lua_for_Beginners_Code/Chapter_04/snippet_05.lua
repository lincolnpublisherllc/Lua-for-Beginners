local p, q, r = 1, 2
print(p, q, r)      -- 1  2  nil