print(math.type(10))     -- integer
print(math.type(3.5))    -- float