local student = "Ada"
local score = 88.255
local line = string.format("Student: %s | Score: %.1f", student, score)
print(line)