local x
print(x)         -- nil