print("Lua" .. " " .. "rocks")   -- Lua rocks
print(#"abc")                    -- 3