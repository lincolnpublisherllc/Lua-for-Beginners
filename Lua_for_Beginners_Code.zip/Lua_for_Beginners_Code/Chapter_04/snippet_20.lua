local s1 = "Hello"
local s2 = 'Lua'
local s3 = [[Line 1