local t1 = {x = 1}
local t2 = {x = 1}
print(t1 == t2)      -- false (different tables)
local t3 = t1
print(t1 == t3)      -- true (same table)