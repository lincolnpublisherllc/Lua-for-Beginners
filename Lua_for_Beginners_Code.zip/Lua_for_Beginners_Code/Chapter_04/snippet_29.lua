print(3 < 5)         -- true
print("apple" < "banana")  -- true (lexicographic)