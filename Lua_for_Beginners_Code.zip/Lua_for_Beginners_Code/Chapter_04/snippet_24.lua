local msg = "Lua is fun"
print(string.upper(msg))          -- LUA IS FUN
print(string.sub(msg, 1, 3))      -- Lua
print(string.find(msg, "fun"))    -- start and end indices
print(string.rep("ha", 3))        -- hahaha
print(string.gsub("2025-09-21", "-", "/"))  -- 2025/09/21