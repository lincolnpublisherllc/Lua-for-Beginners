if 0 then print("0 is truthy") end       -- prints
if "" then print("empty string is truthy") end  -- prints