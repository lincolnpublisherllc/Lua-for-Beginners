local avg = 88.255
print(string.format("Average: %.2f", avg))  -- Average: 88.26