print(type(42))          -- number
print(type("hello"))     -- string
print(type(true))        -- boolean
print(type(nil))         -- nil