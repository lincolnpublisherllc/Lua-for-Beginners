print(5 == 5)        -- true
print("a" == "a")    -- true
print("5" == 5)      -- false (different types)