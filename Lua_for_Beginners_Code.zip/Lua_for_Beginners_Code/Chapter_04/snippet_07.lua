  local inside = "I am inside"
  print(outside)  -- ok
  print(inside)   -- ok
end

print(outside)    -- ok
-- print(inside)  -- error: inside is out of scope