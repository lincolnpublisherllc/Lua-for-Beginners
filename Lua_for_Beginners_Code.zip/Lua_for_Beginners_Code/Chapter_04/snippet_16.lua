local x, y = 7, 3
print(x + y, x - y, x * y)  -- 10  4  21
print(x / y)                -- 2.3333333333333
print(x % y)                -- 1   remainder
print(x ^ y)                -- 343 exponent