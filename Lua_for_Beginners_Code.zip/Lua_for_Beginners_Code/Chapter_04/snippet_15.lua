local a = 12        -- integer
local b = 2.5       -- float
print(a + b)        -- 14.5