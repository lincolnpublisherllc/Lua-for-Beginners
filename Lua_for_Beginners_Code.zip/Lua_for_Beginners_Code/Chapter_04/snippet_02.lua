local a, b, c = 10, 20, 30
print(a, b, c)  -- 10  20  30