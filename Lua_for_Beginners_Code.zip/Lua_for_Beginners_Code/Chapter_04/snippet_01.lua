local age = 21
local name = "Ada"
local pi = 3.14159
local keeps a variable limited to the current block or file.