local n = tonumber("42")   -- 42
local bad = tonumber("abc") -- nil
print(tostring(123) .. " apples") -- "123 apples"