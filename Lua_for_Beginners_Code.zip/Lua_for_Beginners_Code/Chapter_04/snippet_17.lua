local s = 0.1 + 0.2
print(s)                 -- 0.30000000000000004 (typical)