-- safe numeric input
local n = tonumber(io.read())
if n == nil then print("Not a number") end

-- convert anything to string for logging
print("value: " .. tostring({}))   -- value: table: 0x...

-- boolean to string
local ok = true
print(tostring(ok))                -- true