local function approx(a, b, eps)
  return math.abs(a - b) < (eps or 1e-9)
end
print(approx(0.1 + 0.2, 0.3))   -- true