local n = 42
if math.type(n) == "integer" then
  print("n is an integer")
end