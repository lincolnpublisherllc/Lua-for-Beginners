local ages = {alice = 30, bob = 27}         -- a map-like table
print("Alice is " .. ages.alice)

-- Add new entries