-- hello.lua
local name = "Lua learner"
local year = 2025

print("Hello, " .. name .. "!")
print("Welcome to Lua. The year is " .. year)

local a = 7
local b = 5
local sum = a + b
print("7 + 5 = " .. sum)