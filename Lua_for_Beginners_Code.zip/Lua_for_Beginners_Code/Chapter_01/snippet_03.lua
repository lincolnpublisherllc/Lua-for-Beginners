if hour < 12 then
  print("Good morning")
elseif hour < 18 then
  print("Good afternoon")
else
  print("Good evening")
end