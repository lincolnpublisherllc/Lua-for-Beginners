local function map(t, f)
  local out = {}
  for i, v in ipairs(t) do