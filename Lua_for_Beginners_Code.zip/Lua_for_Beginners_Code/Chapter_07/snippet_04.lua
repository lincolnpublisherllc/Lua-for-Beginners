local lo_only = select(1, min_max(12, 7))
print(lo_only)  -- 7