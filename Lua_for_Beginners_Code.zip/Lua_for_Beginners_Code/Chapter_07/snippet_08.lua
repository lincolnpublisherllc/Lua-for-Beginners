local balance = 0

local function deposit(amount)