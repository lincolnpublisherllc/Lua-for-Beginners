local shout = function(s)
  return string.upper(s) .. "!"
end

print(shout("lua"))  -- LUA!