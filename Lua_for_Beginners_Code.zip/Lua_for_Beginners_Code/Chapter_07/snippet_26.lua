  return c
end

io.write("Enter text: ")
local t = io.read() or ""
print("Chars:", count_chars(t))
print("Words:", count_words(t))