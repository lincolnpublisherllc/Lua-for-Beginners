local function greet(name)
  print("Hello, " .. name)
end