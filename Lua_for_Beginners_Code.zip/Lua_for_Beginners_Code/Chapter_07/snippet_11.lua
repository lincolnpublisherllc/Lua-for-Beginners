local function make_multiplier(k)
  return function(x)
    return k * x
  end
end

local times2 = make_multiplier(2)
local times10 = make_multiplier(10)

print(times2(7))    -- 14
print(times10(3))   -- 30