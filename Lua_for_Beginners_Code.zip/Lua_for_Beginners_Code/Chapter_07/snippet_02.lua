local result = add(7, 5)
print(result)   -- 12