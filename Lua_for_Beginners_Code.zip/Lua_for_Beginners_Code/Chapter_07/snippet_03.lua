local function min_max(a, b)
  if a < b then
    return a, b
  else
    return b, a
  end
end

local lo, hi = min_max(12, 7)
print("lo:", lo, "hi:", hi)   -- lo: 7  hi: 12