local function taxable(amount)
  return amount > 1000
end

local function tax(amount)
  if not taxable(amount) then return 0 end
  return amount * 0.075
end

print(tax(800))    -- 0
print(tax(2000))   -- 150