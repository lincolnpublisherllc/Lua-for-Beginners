local function count_chars(s) return #s end
local function count_words(s)
  local c = 0