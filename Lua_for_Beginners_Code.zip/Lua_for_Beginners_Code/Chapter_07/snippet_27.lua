local function convert(amount, rate)
  if not amount or not rate then return nil, "missing values" end
  return amount * rate
end

local money, rate = 10000, 0.0013
local v = convert(money, rate)
print("Converted:", string.format("%.2f", v))