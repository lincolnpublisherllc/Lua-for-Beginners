local function safe_div(a, b)
  if type(a) ~= "number" or type(b) ~= "number" then
    return nil, "numbers required"
  end
  if b == 0 then
    return nil, "division by zero"
  end
  return a / b
end

local q, err = safe_div(12, 0)
if not q then
  print("Error:", err)
end