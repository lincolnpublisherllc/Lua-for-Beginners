-- average of numbers in a list, or nil if empty
local function average(t)
  if #t == 0 then return nil end
  local sum = 0
  for i = 1, #t do sum = sum + t[i] end
  return sum / #t
end