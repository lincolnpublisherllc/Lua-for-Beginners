local function apply(f, a, b)
  return f(a, b)
end

print(apply(ops.sub, 9, 3))  -- 6