print(max_in_list({4, 9, 2}))   -- 9
print(max_in_list({}))          -- nil