local avg, n = safe_average({10, 20, 30})
print(avg, n)  -- 20  3