local function greet_strict(name)
  if name == nil or name == "" then