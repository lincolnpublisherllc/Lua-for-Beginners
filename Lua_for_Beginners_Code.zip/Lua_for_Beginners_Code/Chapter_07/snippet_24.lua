-- helpers
local function is_valid_score(s) return s and s >= 0 and s <= 100 end
local function grade(s)
  if s >= 70 then return "A"
  elseif s >= 60 then return "B"
  elseif s >= 50 then return "C"