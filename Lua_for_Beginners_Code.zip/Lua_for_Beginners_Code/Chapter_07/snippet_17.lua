local cart = {items = {}}

function cart:add(name, price)
  table.insert(self.items, {name = name, price = price})
end

function cart:total()
  local sum = 0
  for _, it in ipairs(self.items) do