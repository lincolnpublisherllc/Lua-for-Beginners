print(to_seconds(2))    -- 120
print(to_minutes(150))  -- 2.5