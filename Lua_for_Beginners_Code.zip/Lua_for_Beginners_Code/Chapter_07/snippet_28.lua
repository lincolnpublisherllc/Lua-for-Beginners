local handlers = {}

function handlers.add(a, b) return a + b end
function handlers.mul(a, b) return a * b end

local function run(op, a, b)
  local f = handlers[op]
  if not f then return nil, "unknown op" end
  return f(a, b)
end

print(run("add", 3, 4))   -- 7
print(run("mul", 3, 4))   -- 12