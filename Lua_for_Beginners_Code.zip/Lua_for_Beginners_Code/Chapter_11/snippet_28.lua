local n = tonumber(io.read())
if not n then print("Invalid") end