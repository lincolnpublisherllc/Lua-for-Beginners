local count = 0
local function inc() count = count + 1 end