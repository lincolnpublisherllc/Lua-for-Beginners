local q, err = safe_div(a, b)
if not q then print("Error:", err) else print(q) end