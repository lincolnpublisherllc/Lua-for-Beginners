local function price(p)
  if p == nil then return nil, "missing price" end
  if p < 0 then return nil, "negative price" end
  return p
end