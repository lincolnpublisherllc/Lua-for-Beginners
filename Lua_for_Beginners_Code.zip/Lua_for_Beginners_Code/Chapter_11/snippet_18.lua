local ok = math.abs((0.1 + 0.2) - 0.3) < 1e-9
print(string.format("Average: %.2f", 88.255))