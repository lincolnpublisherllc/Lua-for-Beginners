local t = {"a","b","c"}
print(t[0])   -- nil