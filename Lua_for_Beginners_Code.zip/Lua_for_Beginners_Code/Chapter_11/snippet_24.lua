local a, b = 3, 4
print("Total: " .. a + b)