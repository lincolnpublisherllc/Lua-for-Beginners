if 0 then print("This prints") end
if "" then print("This prints") end