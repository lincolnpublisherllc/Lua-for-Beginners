local qty = tonumber(io.read())  -- could be nil
print(qty + 1)