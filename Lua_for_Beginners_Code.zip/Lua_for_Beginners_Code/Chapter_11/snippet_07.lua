local qty = tonumber(io.read())
if not qty then
  print("Enter a number")
else
  print(qty + 1)
end