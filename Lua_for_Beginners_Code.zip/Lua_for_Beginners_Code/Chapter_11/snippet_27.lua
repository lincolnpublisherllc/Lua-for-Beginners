local dense = {}
for _, v in ipairs(t) do table.insert(dense, v) end