local keep = {}
for _, v in ipairs(t) do
  if should_keep(v) then table.insert(keep, v) end
end