local n = tonumber("5")
print(n == 5)  -- true