local n
print("Total: " .. n)