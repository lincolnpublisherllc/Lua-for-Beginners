local core = require("app.core")
local avg, err = core.average({10, 20, 30})
print(avg)  -- 20