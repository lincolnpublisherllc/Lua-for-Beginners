local function match_lines(path, pat)
  return coroutine.wrap(function()
    local f = io.open(path, "r"); if not f then return end