for i = 1, 5 do print(i) end

local a = {3, 5, 7}
for i, v in ipairs(a) do print(i, v) end

local m = {a=1, b=2}
for k, v in pairs(m) do print(k, v) end

local n = 3