-- mymod.lua
local M = {}
function M.double(x) return x * 2 end
return M

-- main.lua
local mymod = require("mymod")
print(mymod.double(5))