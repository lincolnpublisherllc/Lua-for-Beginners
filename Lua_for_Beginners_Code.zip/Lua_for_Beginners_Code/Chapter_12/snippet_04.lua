function Account.new(balance)
  return setmetatable({balance = balance or 0}, Account)
end

function Account:deposit(n)