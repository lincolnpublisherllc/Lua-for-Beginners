local function add(a, b) return a + b end
local sum = add(2, 3)

-- methods with :
local Account = {}