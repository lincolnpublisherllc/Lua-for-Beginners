local n = 42
local s = "hello"
local t = {1, 2, 3}
print(type(n), type(s), type(t))  -- number string table