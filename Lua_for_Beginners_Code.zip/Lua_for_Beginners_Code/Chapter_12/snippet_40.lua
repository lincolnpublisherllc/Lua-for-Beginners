local ok, res = pcall(function() return 10 / 0 end)
if not ok then print("Error:", res) end