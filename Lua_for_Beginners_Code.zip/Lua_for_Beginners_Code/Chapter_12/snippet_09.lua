local function readonly(t)
  return setmetatable({}, {