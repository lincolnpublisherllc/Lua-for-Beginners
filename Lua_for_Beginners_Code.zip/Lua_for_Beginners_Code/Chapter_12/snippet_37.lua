if x > 10 then
  print("big")
elseif x == 10 then
  print("ten")
else
  print("small")
end