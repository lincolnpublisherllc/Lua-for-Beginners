print(string.format("%.2f", 5/3))
print(math.floor(5.7), math.ceil(5.1))