local defaults = {theme = "light", sound = true}

local config = setmetatable({}, {