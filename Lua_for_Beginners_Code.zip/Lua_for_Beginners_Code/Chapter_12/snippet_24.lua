local function timeit(label, f, ...)
  local t0 = os.clock()
  local result = {f(...)}
  local t1 = os.clock()
  print(string.format("%s: %.4f sec", label, t1 - t0))
  return table.unpack(result)
end