if not ok then
  print(msg)