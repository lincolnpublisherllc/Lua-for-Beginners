function Account.new(b) return setmetatable({balance=b or 0}, Account) end
function Account:deposit(n) self.balance = self.balance + n end