local name = "Ada"
print("Hi, " .. name)
print(string.format("Pi: %.2f", 3.14159))
print(#"hello")            -- 5