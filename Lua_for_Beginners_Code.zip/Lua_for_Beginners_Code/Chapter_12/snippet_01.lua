-- app/core.lua
local M = {}

function M.average(t)
  if #t == 0 then return nil, "empty" end
  local s = 0
  for i = 1, #t do s = s + t[i] end
  return s / #t
end

return M