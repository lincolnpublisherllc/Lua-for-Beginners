-- tests/core_spec.lua
local core = require("app.core")

local function assert_eq(a, b, label)
  if a ~= b then