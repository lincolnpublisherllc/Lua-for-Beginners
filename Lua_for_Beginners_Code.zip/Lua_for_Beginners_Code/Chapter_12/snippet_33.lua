-- list
local nums = {10, 20, 30}
table.insert(nums, 40)
print(nums[1], #nums)

-- map
local user = {name = "Ada", city = "Lagos"}