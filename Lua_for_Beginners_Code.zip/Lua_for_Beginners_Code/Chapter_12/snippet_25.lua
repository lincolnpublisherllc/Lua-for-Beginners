-- app/json.lua
local cjson = require("cjson")  -- or another json library

local M = {}

function M.encode(t)
  return cjson.encode(t)
end

function M.decode(s)
  local ok, res = pcall(cjson.decode, s)
  if not ok then return nil, "bad json" end
  return res
end

return M