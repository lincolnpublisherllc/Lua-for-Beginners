local function main()
  -- your program
  return true
end

local ok, msg = xpcall(main, function(err)
  return debug.traceback("Fatal: " .. tostring(err), 2)