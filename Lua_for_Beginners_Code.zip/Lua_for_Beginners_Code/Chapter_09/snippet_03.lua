local function inner(t) return t.x + 1 end
local function outer() return inner(nil) end
print(outer())