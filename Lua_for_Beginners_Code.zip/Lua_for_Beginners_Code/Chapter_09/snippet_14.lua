local t
print(t.x)   -- fails