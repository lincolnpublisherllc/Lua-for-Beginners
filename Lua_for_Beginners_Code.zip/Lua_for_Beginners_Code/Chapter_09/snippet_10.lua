local function handler(msg)
  return debug.traceback("Error: " .. tostring(msg), 2)
end

local ok, res = xpcall(function() return risky(-5) end, handler)
print(ok, res)