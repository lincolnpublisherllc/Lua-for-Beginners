  if type(t) ~= "table" then
    print(indent .. tostring(t))
    return
  end
  print(indent .. "{")
  for k, v in pairs(t) do
    io.write(indent .. "  " .. tostring(k) .. " = ")
    if type(v) == "table" then