local function average(t)
  if #t == 0 then return nil end
  local sum = 0
  for i = 1, #t do
    -- debug print
    -- print("i:", i, "t[i]:", t[i], "sum:", sum)