io.write("Age: ")
local age = io.read()
print(age + 1)   -- fails if input is not numeric