local user = nil
print(user.name)     -- attempt to index a nil value