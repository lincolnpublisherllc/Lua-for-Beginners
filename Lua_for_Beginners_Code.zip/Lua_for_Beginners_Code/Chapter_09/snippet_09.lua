local function risky(n)
  if n < 0 then error("negative not allowed") end
  return n * 2
end

local ok, res = pcall(risky, -5)
if not ok then
  print("Error:", res)
else
  print("Result:", res)
end