local function safe_div(a, b)
  if type(a) ~= "number" or type(b) ~= "number" then
    return nil, "numbers required"
  end
  if b == 0 then
    return nil, "cannot divide by zero"
  end
  return a / b
end