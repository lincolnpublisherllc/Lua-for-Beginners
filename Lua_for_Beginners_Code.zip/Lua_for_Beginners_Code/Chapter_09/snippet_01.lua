-- missing 'end'
if true then
  print("Hi")
-- <no end here>