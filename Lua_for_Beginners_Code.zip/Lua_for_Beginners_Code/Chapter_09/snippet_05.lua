print("type:", type(v))
print("is nil?", v == nil)
print(string.format("value as number: %s", tostring(tonumber(v))))