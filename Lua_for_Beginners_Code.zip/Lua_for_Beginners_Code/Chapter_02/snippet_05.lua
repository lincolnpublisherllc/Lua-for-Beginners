local learner = "Your Name"
local goal = "practice Lua for 20 minutes a day"
print("Hello " .. learner .. ", today you will " .. goal .. ".")