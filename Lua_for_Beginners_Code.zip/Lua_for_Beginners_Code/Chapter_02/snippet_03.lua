local lfs = require("lfs")
print("Current directory is:", lfs.currentdir())