#!/usr/bin/env lua
print("Hello, Lua as an executable")