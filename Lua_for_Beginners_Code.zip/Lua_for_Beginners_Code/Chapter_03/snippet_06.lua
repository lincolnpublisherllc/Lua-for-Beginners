if not c then
  print("Invalid input.")
else
  local f = (c * 9 / 5) + 32
  print(c .. " C is " .. f .. " F")
end