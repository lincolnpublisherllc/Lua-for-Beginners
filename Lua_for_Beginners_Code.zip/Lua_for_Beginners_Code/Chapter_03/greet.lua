-- save as greet.lua
io.write("What is your name? ")
local name = io.read()
print("Hello, " .. name .. "!")