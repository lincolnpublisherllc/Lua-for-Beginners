io.write("Enter second number: ")
local b = tonumber(io.read())

if a == nil or b == nil then
  print("Please enter valid numbers.")
else
  print("Sum:", a + b)
end