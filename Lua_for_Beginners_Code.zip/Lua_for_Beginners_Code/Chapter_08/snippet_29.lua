local function valid_user(t)
  return type(t) == "table"