local nums = {10, 30, 40}
table.insert(nums, 2, 20)  -- at index 2
print(nums[1], nums[2], nums[3], nums[4])  -- 10  20  30  40