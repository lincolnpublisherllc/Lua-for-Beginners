local t = {3, 5, 7}
for i, v in ipairs(t) do
  print(i, v)
end