local colors = {"red", "green", "blue"}  -- same as {[1]="red",[2]="green",[3]="blue"}
print(colors[1])                         -- red
print(#colors)                           -- 3  length for list-like tables