local function merge(a, b)
  local out = {}
  for k, v in pairs(a) do out[k] = v end
  for k, v in pairs(b) do out[k] = v end
  return out
end

local base = {theme = "light", sound = true}
local override = {sound = false}
local cfg = merge(base, override)
print(cfg.theme, cfg.sound)   -- light  false