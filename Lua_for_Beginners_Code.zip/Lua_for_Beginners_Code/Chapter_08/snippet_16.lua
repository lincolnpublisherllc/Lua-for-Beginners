local a = {x = 1}
local b = a