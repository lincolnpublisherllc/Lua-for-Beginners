print(last({5, 7, 9}))   -- 9
print(last({}))          -- nil