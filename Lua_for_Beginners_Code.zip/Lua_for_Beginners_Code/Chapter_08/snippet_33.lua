local q = {}
table.insert(q, "a")
table.insert(q, "b")
local first = table.remove(q, 1)  -- remove from index 1
print(first)                      -- a