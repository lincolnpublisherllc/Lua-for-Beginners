local t = {1, nil, 3, nil, 5}
local clean = {}
for _, v in ipairs(t) do
  if v ~= nil then table.insert(clean, v) end
end
print(table.concat(clean, ", "))  -- 1, 3, 5