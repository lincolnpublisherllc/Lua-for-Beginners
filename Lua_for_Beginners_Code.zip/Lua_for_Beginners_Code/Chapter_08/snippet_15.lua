local function make_student(name, scores)
  return {name = name, scores = scores or {}}
end

local s = make_student("Ada", {90, 84, 95})
print(s.name, #s.scores)   -- Ada  3