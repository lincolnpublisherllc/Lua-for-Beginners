for key, value in pairs(user) do
  print(key, value)
end