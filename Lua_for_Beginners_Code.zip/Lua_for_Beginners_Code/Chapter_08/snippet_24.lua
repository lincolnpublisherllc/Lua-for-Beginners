local function map(t, f)
  local out = {}
  for i, v in ipairs(t) do out[i] = f(v) end
  return out
end

local function filter(t, p)
  local out = {}
  for _, v in ipairs(t) do if p(v) then table.insert(out, v) end end
  return out
end

local doubled = map({1, 2, 3}, function(x) return x * 2 end)
print(table.concat(doubled, ", "))  -- 2, 4, 6