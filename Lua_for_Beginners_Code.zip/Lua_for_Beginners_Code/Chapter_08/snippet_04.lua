local words = {"Lua", "is", "fun"}
print(table.concat(words, " "))  -- Lua is fun