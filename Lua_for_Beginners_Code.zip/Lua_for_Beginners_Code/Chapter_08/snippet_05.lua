local function copy_list(t)
  local out = {}
  for i = 1, #t do out[i] = t[i] end
  return out
end