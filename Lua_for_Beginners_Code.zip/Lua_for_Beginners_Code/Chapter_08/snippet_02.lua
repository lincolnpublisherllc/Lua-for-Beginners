table.insert(colors, "yellow")   -- append at the end
print(#colors)                   -- 4
print(colors[#colors])           -- yellow

local last = table.remove(colors)  -- removes and returns last item
print(last)                        -- yellow