local function average(t)
  local s = 0
  for i = 1, #t do s = s + t[i] end
  return s / #t
end

for _, st in ipairs(students) do
  local avg = average(st.scores)
  print(string.format("%s | Avg: %.2f", st.name, avg))
end