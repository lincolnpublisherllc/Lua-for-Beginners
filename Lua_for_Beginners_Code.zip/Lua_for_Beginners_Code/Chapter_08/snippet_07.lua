local scores = {12, 5, 18, 7}
table.sort(scores)                       -- ascending
print(table.concat(scores, ", "))        -- 5, 7, 12, 18

local names = {"zara", "Ada", "tayo"}
table.sort(names, function(a, b) return a:lower() < b:lower() end)
print(table.concat(names, ", "))         -- Ada, tayo, zara