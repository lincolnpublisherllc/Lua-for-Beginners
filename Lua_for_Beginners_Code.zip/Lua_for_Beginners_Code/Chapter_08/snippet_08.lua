local user = {name = "Ada", city = "Lagos", active = true}

print(user.name)         -- Ada
print(user["city"])      -- Lagos