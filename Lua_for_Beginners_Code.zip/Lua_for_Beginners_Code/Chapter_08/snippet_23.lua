local settings = {theme = "light", sound = true}
for k, v in pairs(settings) do
  print(k, v)
end