local function compact_map(t)
  local out = {}
  for k, v in pairs(t) do
    if v ~= nil and v ~= "" then out[k] = v end
  end
  return out
end