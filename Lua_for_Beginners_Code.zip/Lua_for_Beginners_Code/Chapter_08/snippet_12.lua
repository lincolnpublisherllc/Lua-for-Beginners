table.sort(keys)
for _, k in ipairs(keys) do print(k, user[k]) end