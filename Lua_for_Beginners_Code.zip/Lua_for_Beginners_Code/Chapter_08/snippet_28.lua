local by_name = {}
for _, st in ipairs(students) do by_name[st.name] = st end

local who = by_name["Ada"]
print(who and who.name)  -- Ada