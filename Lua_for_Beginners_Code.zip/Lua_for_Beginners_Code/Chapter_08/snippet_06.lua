local t = {1, 2, 3, 4}
for i = 1, math.floor(#t / 2) do
  local j = #t - i + 1