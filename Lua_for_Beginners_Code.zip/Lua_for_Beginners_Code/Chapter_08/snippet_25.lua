local function reduce(t, f, init)
  local acc = init
  for _, v in ipairs(t) do acc = f(acc, v) end
  return acc
end

local sum = reduce({1, 2, 3, 4}, function(a, v) return a + v end, 0)
print(sum)  -- 10