local a = {x=1}
local b = {x=1}
print(a == b)     -- false
local c = a
print(a == c)     -- true