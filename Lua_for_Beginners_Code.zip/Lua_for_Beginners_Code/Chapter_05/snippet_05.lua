print(5 == 5)        -- true
print(5 ~= 4)        -- true  not equal
print(3 < 5)         -- true
print(3 <= 3)        -- true
print(7 > 2)         -- true
print(7 >= 8)        -- false