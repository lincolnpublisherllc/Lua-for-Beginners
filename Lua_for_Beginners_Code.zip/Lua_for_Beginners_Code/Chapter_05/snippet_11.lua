print(2 + 3 * 4)         -- 14
print((2 + 3) * 4)       -- 20
print("a" .. "b" .. 1+2) -- 3 is added last: same as ("a" .. "b" .. 1) + 2  -> error
print("a" .. ("b" .. (1 + 2))) -- "ab3"