local title = "Lua"
print(#title)      -- 3
print(title .. " guide")  -- Lua guide