local user = {name = "Ada", age = 21}
-- only print age if present