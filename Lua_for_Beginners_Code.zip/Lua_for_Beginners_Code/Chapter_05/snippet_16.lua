local ok, value = true, 42
local result = ok and value or "none"
print(result)  -- 42