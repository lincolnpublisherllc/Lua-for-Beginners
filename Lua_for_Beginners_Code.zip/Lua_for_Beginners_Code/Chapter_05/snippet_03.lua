local n = 7
print(-n)      -- -7   numeric negation

local t = true
print(not t)   -- false  logical negation