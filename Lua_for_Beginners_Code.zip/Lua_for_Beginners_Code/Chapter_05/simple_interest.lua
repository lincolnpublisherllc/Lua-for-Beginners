-- simple_interest.lua
io.write("Principal: ")
local p = tonumber(io.read())
io.write("Rate (percent): ")
local r = tonumber(io.read())
io.write("Time (years): ")
local t = tonumber(io.read())

if not p or not r or not t then
  print("Please enter valid numbers.")
else
  local interest = p * (r / 100) * t
  print(string.format("Interest = %.2f", interest))
end