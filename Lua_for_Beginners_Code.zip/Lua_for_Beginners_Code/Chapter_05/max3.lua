-- max3.lua
local a, b, c = 12, 9, 15
local max = a
if b > max then max = b end
if c > max then max = c end
print("Max:", max)