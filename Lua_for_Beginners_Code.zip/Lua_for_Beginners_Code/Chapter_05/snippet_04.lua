local name, year = "Ada", 2025
print("Hello, " .. name .. ". Year: " .. tostring(year))