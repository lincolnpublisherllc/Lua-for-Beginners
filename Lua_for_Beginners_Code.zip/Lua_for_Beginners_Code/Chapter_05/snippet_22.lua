local name, avg = "Tayo", 88.255
print(string.format("%s | Average: %.2f", name, avg))