-- pwd_hint.lua
io.write("Enter password: ")
local pwd = io.read() or ""
local long_enough = #pwd >= 8
local has_digit = pwd:match("%d") ~= nil
local hint = long_enough and has_digit and "ok" or "weak"
print("Password is:", hint)