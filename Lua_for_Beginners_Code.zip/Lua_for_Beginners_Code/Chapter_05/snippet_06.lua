print("apple" < "banana")   -- true
print("Zoo" < "apple")      -- false (uppercase sorts before lowercase)