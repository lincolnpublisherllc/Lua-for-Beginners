local q = 17 / 3
print(q)                          -- 5.6666666667
print(math.floor(q))              -- 5
print(math.ceil(q))               -- 6
print(string.format("%.2f", q))   -- 5.67