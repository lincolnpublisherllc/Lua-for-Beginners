print(true and "ok")      -- "ok"
print(false and "ok")     -- false
print(false or "alt")     -- "alt"
print("value" or "alt")   -- "value"