local function hypotenuse(a, b)
  local sumsq = a^2 + b^2
  return math.sqrt(sumsq)
end
print(hypotenuse(3, 4))  -- 5