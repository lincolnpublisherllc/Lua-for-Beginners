local input = nil
local username = input or "guest"
print(username)   -- guest