local function clamp(x, lo, hi)
  if x < lo then return lo end
  if x > hi then return hi end
  return x
end
print(clamp(15, 0, 10))  -- 10