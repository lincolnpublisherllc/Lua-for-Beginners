io.write("Enter number: ")
local n = tonumber(io.read())
local x = n or 0
print("Twice:", x * 2)