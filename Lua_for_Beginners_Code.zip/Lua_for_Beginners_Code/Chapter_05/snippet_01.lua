local a, b = 12, 5
print(a + b)   -- 17   addition
print(a - b)   -- 7    subtraction
print(a * b)   -- 60   multiplication
print(a / b)   -- 2.4  floating division
print(a % b)   -- 2    remainder
print(a ^ b)   -- 248832 exponent