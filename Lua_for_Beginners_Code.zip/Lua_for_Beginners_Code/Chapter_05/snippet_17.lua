local conf = nil
local theme = conf and conf.theme or "light"
print(theme)  -- light