for index, value in ipairs(colors) do
  print(index, value)
end