for key, value in pairs(ages) do
  print(key, value)
end