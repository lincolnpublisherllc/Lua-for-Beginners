io.write("Enter score: ")
local s = tonumber(io.read())

if not s then
  print("Invalid")
elseif s >= 70 then
  print("A")
elseif s >= 60 then
  print("B")
elseif s >= 50 then
  print("C")
else
  print("D")
end