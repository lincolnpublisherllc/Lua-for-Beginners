for i = 1, 5 do
  if i % 2 == 0 then
    -- skip even numbers
  else
    print(i)
  end
end