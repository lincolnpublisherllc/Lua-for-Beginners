io.write("Number: ")
local n = tonumber(io.read())
if not n then
  print("Invalid number")
else
  for i = 1, 12 do
    print(string.format("%d x %d = %d", n, i, n * i))
  end
end