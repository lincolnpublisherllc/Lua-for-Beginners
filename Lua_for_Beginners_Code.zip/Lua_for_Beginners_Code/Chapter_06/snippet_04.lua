local function greet(name)
  if not name or name == "" then
    print("Please enter your name")
    return
  end
  print("Hello, " .. name)
end