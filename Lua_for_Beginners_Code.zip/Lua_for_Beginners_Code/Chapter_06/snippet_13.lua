for _, v in ipairs({-3, 0, 7}) do
  print(v, classify(v))
end