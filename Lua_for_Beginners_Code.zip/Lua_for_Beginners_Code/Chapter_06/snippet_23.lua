  if not guess then
    print("Please enter a number.")
  elseif guess < secret then
    print("Too low")
  elseif guess > secret then
    print("Too high")
  end
until guess == secret

print("Correct in " .. tries .. " tries")