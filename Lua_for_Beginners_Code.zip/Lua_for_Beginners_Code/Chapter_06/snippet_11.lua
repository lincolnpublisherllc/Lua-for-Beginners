for i = 1, 10 do
  if i == 4 then