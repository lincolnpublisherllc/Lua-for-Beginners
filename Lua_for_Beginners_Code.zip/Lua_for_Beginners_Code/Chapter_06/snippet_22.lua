local secret = 7
local tries = 0
local guess

repeat
  io.write("Guess 1 to 10: ")