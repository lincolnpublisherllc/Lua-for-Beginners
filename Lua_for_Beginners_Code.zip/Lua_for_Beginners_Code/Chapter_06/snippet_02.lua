local temp = 24

if temp >= 30 then
  print("Hot")
elseif temp >= 20 then
  print("Warm")
else
  print("Cool")
end