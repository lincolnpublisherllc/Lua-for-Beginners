local score = 72

if score >= 70 then
  print("Pass")
end