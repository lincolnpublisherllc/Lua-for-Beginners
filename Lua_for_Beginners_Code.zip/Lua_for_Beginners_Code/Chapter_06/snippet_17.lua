local words = {"lua", "is", "fun", "lua", "is"}
local freq = {}

for _, w in ipairs(words) do