local data = {7, 12, -3, 4}
local min, max = data[1], data[1]

for i = 2, #data do
  local v = data[i]
  if v < min then min = v end
  if v > max then max = v end
end

print("Min:", min, "Max:", max)