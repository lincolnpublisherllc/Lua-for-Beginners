local nums = {5, 12, 7, 20, 3}
local big = {}

for _, n in ipairs(nums) do
  if n >= 10 then
    table.insert(big, n)
  end
end

-- print result
for i, v in ipairs(big) do
  print(i, v)
end