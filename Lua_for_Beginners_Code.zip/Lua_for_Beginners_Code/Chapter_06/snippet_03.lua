if age >= 18 and has_id then
  print("Allowed")
else
  print("Not allowed")
end