  elseif cmd == "done" then
    local ok, err = complete_task(rest)
    if not ok then print("Error:", err) end
  elseif cmd == "save" then
    local ok, err = save_file(rest ~= "" and rest or "tasks.txt")
    if ok then print("Saved.") else print("Error:", err) end
  elseif cmd == "load" then
    local ok, err = load_file(rest ~= "" and rest or "tasks.txt")
    if ok then print("Loaded.") else print("Error:", err) end
  elseif cmd == "help" then