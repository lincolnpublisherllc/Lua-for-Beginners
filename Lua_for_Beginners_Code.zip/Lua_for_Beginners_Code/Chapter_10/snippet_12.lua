  io.write("> ")
  local line = io.read()
  if not line or line == "q" then
    print("Bye")