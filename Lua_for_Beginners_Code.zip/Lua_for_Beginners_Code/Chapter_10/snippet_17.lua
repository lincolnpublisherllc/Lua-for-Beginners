      print("New best score:", best)
    else
      print("Best score remains:", best)
    end
  end
end