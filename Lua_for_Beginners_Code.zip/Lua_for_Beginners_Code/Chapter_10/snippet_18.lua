local function log(...)
  print("[LOG]", ...)
end