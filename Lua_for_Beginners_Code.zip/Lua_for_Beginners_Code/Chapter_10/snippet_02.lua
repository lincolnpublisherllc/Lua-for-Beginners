  if not index or index < 1 or index > #tasks then
    return nil, "invalid index"
  end