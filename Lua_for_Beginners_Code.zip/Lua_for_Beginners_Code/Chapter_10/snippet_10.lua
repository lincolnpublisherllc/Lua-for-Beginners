  elseif cmd == "quit" then
    print("Goodbye")