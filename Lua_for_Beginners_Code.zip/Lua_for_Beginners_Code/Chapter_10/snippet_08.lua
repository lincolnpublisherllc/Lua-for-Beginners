  io.write("> ")
  local line = io.read()
  if not line then break end
  local cmd, rest = line:match("^(%S+)%s*(.*)$")
  if cmd == "add" then
    local ok, err = add_task(rest)
    if not ok then print("Error:", err) end
  elseif cmd == "list" then