-- game.lua

math.randomseed(os.time())

local best = nil

local function play_round()
  local secret = math.random(1, 20)
  local tries = 0
  local limit = 6
  print("Guess a number 1 to 20. You have " .. limit .. " tries.")