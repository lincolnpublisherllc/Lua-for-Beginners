    local doneflag, text = line:match("^(%d)%s+(.*)$")
    local done = doneflag == "1"
    table.insert(tasks, {text = text or "", done = done})
  end