  return true
end

local function save_file(path)
  local f, err = io.open(path, "w")
  if not f then return nil, err end
  for _, t in ipairs(tasks) do
    -- format: done<TAB>text