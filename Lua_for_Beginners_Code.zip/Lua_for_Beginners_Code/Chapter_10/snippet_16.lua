  elseif ans == "y" then
    local s = play_round()
    if not best or s > best then