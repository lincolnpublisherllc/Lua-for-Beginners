      if g < secret then
        print("Too low")
      elseif g > secret then
        print("Too high")
      else
        local score = 100 - (tries - 1) * 15
        if score < 10 then score = 10 end
        print("Correct in " .. tries .. " tries. Score: " .. score)
        return score
      end
    end
  end

  print("Out of tries. Secret was " .. secret)
  return 0
end

print("Number Game. Type 'q' to quit.")