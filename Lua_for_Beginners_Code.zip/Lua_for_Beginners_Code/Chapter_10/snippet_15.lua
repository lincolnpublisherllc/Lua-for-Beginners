  io.write("Play a round? (y/n): ")
  local ans = io.read()
  if not ans or ans == "q" or ans == "n" then
    print("Goodbye")