  return true
end

local function load_file(path)
  local f = io.open(path, "r")
  if not f then return nil, "could not open file" end