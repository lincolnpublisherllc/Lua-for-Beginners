  return true
end

local function print_help()
  print([[