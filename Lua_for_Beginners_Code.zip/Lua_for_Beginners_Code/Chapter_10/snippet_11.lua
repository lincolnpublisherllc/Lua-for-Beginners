  elseif cmd == "" or cmd == nil then
    -- ignore empty
  else
    print("Unknown command. Type 'help'.")
  end
end