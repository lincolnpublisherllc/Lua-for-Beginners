-- calc.lua

local function parse_num(s)
  local n = tonumber(s)
  if not n then return nil, "not a number" end
  return n
end

local function compute(a, op, b)
  if op == "+" then return a + b
  elseif op == "-" then return a - b
  elseif op == "*" then return a * b
  elseif op == "/" then
    if b == 0 then return nil, "divide by zero" end
    return a / b
  else
    return nil, "unknown operator"
  end
end

local function run_once(line)
  local a, op, b = line:match("^%s*(%-?[%d%.]+)%s*([%+%-%*/])%s*(%-?[%d%.]+)%s*$")
  if not a then return nil, "format: <a> <op> <b>" end
  local na, errA = parse_num(a); if not na then return nil, errA end
  local nb, errB = parse_num(b); if not nb then return nil, errB end
  return compute(na, op, nb)
end

print("Calculator. Example: 12 + 3")