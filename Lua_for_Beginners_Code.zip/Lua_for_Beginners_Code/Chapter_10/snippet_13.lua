    io.write("Your guess: ")
    local g = tonumber(io.read())
    if not g then
      print("Enter a number")
    else