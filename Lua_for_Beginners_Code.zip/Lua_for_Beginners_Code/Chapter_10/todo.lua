-- todo.lua

-- in memory database
local tasks = {}

-- helpers
local function add_task(text)
  if not text or text == "" then
    return nil, "task text is required"
  end
  table.insert(tasks, {text = text, done = false})
  return true
end

local function list_tasks()
  if #tasks == 0 then
    print("No tasks.")
    return
  end
  for i, t in ipairs(tasks) do
    local box = t.done and "[x]" or "[ ]"
    print(string.format("%2d %s %s", i, box, t.text))
  end
end

local function complete_task(index)